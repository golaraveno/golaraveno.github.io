﻿using Microsoft.AspNetCore.Mvc;

namespace WebCoreDocker.Controllers
{
    [Route("Home")]
    public class HomeController : Controller
    {
        [HttpGet]
        public string Index()
        {
            //string s = "";
            //for (int i = 0; i < 100000; i++)
            //{
            //    s += "Www";
            //}

            return "aaaa";
        }
    }
}